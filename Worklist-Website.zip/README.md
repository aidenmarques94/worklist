# Worklist Website

Worklist is a browser-based personal task website built around one permanent task ledger. It turns rough notes into proposed actions, manages active/waiting/completed work, preserves searchable history, and can use the SharePoint `GPT To Do Database.csv` file as its source of truth.

## Website features

- Add and edit tasks
- Mark tasks complete without deleting history
- Active / Today / Waiting-Blocked / Completed / All views
- Search tasks, projects, notes, and dependencies
- Priority and project filters
- Paste rough notes and review extracted action items before saving
- Duplicate protection for identical active tasks
- CSV export
- Local CSV mode for development
- SharePoint CSV mode for production
- Microsoft Graph token acquisition using an Entra application
- Dockerfile and Azure App Service deployment workflow

## Run locally

Requires Node.js 18+ (Node 20 recommended).

```bash
npm start
```

Open `http://localhost:3000`.

Local development writes to `data/GPT To Do Database.csv`.

## Task schema

`Task, Status, Priority, Project, Due Date, Completed Date, Waiting On, Notes`

Statuses: `Not Started`, `In Progress`, `Waiting`, `Blocked`, `Completed`, `Canceled`.

Priorities: `P0 Urgent`, `P1 High`, `P2 Normal`, `P3 Later`.

## SharePoint production mode

Copy `.env.example` into your hosting environment and set `STORAGE_MODE=sharepoint` plus Microsoft Entra and SharePoint identifiers. Do not commit secrets.

See `docs/AZURE-DEPLOYMENT.md` for the exact production setup.

## Architecture

`Browser -> Worklist website/API -> Microsoft Graph -> SharePoint GPT To Do Database.csv`

The browser never receives the Microsoft Graph client secret.
