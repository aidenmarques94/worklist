const http = require('http');
const fs = require('fs/promises');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const CSV_PATH = path.join(ROOT, 'data', 'GPT To Do Database.csv');
const HEADERS = ['Task','Status','Priority','Project','Due Date','Completed Date','Waiting On','Notes'];
const ACTIVE = new Set(['Not Started','In Progress','Waiting','Blocked']);

function send(res, status, body, type='application/json; charset=utf-8') {
  res.writeHead(status, {'Content-Type': type, 'Cache-Control':'no-store'});
  res.end(type.startsWith('application/json') ? JSON.stringify(body) : body);
}
function today(){ return new Date().toISOString().slice(0,10); }
function escId(s){ return crypto.createHash('sha1').update(String(s)).digest('hex').slice(0,12); }

function parseCSV(s){
  const rows=[]; let row=[], cell='', q=false;
  for(let i=0;i<s.length;i++){
    const c=s[i];
    if(q){
      if(c==='"' && s[i+1]==='"'){cell+='"';i++;}
      else if(c==='"') q=false;
      else cell+=c;
    } else {
      if(c==='"') q=true;
      else if(c===','){row.push(cell);cell='';}
      else if(c==='\n'){row.push(cell);rows.push(row);row=[];cell='';}
      else if(c!=='\r') cell+=c;
    }
  }
  if(cell.length || row.length){row.push(cell);rows.push(row);}
  return rows;
}
function csvEscape(v=''){ v=String(v??''); return /[",\n\r]/.test(v) ? '"'+v.replace(/"/g,'""')+'"' : v; }
function toCSV(tasks){
  return [HEADERS.join(','), ...tasks.map(t => [t.task,t.status,t.priority,t.project,t.due,t.completed,t.waiting,t.notes].map(csvEscape).join(','))].join('\n')+'\n';
}
function fromCSV(text){
  const rows=parseCSV(text).filter(r=>r.some(x=>String(x).trim()!==''));
  if(!rows.length) return [];
  const h=rows.shift().map(x=>x.trim()); const ix=n=>h.indexOf(n);
  return rows.map((r,index)=>({
    id: escId(index+'|'+(r[ix('Task')]||'')), row:index,
    task:r[ix('Task')]||'', status:r[ix('Status')]||'Not Started', priority:r[ix('Priority')]||'P2 Normal',
    project:r[ix('Project')]||'', due:r[ix('Due Date')]||'', completed:r[ix('Completed Date')]||'',
    waiting:r[ix('Waiting On')]||'', notes:r[ix('Notes')]||''
  }));
}

let tokenCache = { token: '', expiresAt: 0 };
async function graphToken(){
  if(process.env.GRAPH_ACCESS_TOKEN) return process.env.GRAPH_ACCESS_TOKEN;
  const tenant=process.env.AZURE_TENANT_ID;
  const client=process.env.AZURE_CLIENT_ID;
  const secret=process.env.AZURE_CLIENT_SECRET;
  if(!tenant || !client || !secret) throw new Error('SharePoint mode requires either GRAPH_ACCESS_TOKEN or AZURE_TENANT_ID/AZURE_CLIENT_ID/AZURE_CLIENT_SECRET.');
  if(tokenCache.token && Date.now() < tokenCache.expiresAt - 60000) return tokenCache.token;
  const form=new URLSearchParams({client_id:client,client_secret:secret,scope:'https://graph.microsoft.com/.default',grant_type:'client_credentials'});
  const r=await fetch(`https://login.microsoftonline.com/${encodeURIComponent(tenant)}/oauth2/v2.0/token`,{
    method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:form
  });
  const data=await r.json();
  if(!r.ok || !data.access_token) throw new Error(`Microsoft token request failed: ${r.status} ${data.error_description||data.error||'Unknown error'}`);
  tokenCache={token:data.access_token,expiresAt:Date.now()+(Number(data.expires_in||3600)*1000)};
  return tokenCache.token;
}
function graphContentUrl(){
  if(process.env.SHAREPOINT_FILE_CONTENT_URL) return process.env.SHAREPOINT_FILE_CONTENT_URL;
  const drive=process.env.SHAREPOINT_DRIVE_ID;
  const item=process.env.SHAREPOINT_ITEM_ID;
  if(!drive || !item) throw new Error('SharePoint mode requires SHAREPOINT_FILE_CONTENT_URL or SHAREPOINT_DRIVE_ID/SHAREPOINT_ITEM_ID.');
  return `https://graph.microsoft.com/v1.0/drives/${encodeURIComponent(drive)}/items/${encodeURIComponent(item)}/content`;
}
async function readRaw(){
  if((process.env.STORAGE_MODE||'local')==='sharepoint'){
    const token=await graphToken();
    const r=await fetch(graphContentUrl(),{headers:{Authorization:`Bearer ${token}`}});
    if(!r.ok) throw new Error(`SharePoint read failed: ${r.status} ${await r.text()}`);
    return await r.text();
  }
  return await fs.readFile(CSV_PATH,'utf8');
}
async function writeRaw(text){
  if((process.env.STORAGE_MODE||'local')==='sharepoint'){
    const token=await graphToken();
    const r=await fetch(graphContentUrl(),{method:'PUT',headers:{Authorization:`Bearer ${token}`,'Content-Type':'text/csv'},body:text});
    if(!r.ok) throw new Error(`SharePoint write failed: ${r.status} ${await r.text()}`);
    return;
  }
  await fs.writeFile(CSV_PATH,text,'utf8');
}
async function readTasks(){ return fromCSV(await readRaw()); }
async function saveTasks(tasks){ await writeRaw(toCSV(tasks)); }

function body(req){ return new Promise((resolve,reject)=>{let s='';req.on('data',c=>{s+=c;if(s.length>2e6)req.destroy();});req.on('end',()=>{try{resolve(s?JSON.parse(s):{});}catch(e){reject(e);}});req.on('error',reject);}); }
function normalizeTask(x={}){
  return {
    task:String(x.task||'').trim(), status:String(x.status||'Not Started'), priority:String(x.priority||'P2 Normal'),
    project:String(x.project||'').trim(), due:String(x.due||''), completed:String(x.completed||''),
    waiting:String(x.waiting||'').trim(), notes:String(x.notes||'').trim()
  };
}
function parseNotes(text=''){
  const lines=String(text).split(/\n+/).map(s=>s.trim()).filter(Boolean).filter(s=>!/^https?:\/\//i.test(s));
  const action=/\b(create|make|build|send|follow up|meet|ask|confirm|determine|investigate|review|get|define|prepare|outline|bring|schedule|start|work on|understand|check|figure out|create ticket|finalize|draft|test|validate|coordinate)\b/i;
  const context=[]; const out=[];
  for(const line of lines){
    if(line.length>300){context.push(line);continue;}
    let task='';
    if(action.test(line)) task=line.replace(/^[-*•\d.)\s]+/,'').trim();
    else if(/[?]$/.test(line)) task='Determine '+line.replace(/[?]+$/,'').trim();
    if(task){ task=task.charAt(0).toUpperCase()+task.slice(1); if(!/[.!?]$/.test(task))task+='.'; out.push({task,notes:line}); }
    else context.push(line);
  }
  const unique=[...new Map(out.map(x=>[x.task.toLowerCase(),x])).values()];
  if(context.length && unique.length===1) unique[0].notes=[unique[0].notes,...context].join(' | ');
  return unique;
}

async function api(req,res,url){
  try{
    if(req.method==='GET' && url.pathname==='/api/health') return send(res,200,{ok:true,storage:process.env.STORAGE_MODE||'local'});
    if(req.method==='GET' && url.pathname==='/api/tasks') return send(res,200,{tasks:await readTasks(),storage:process.env.STORAGE_MODE||'local'});
    if(req.method==='POST' && url.pathname==='/api/parse-notes'){
      const b=await body(req); return send(res,200,{proposals:parseNotes(b.text)});
    }
    if(req.method==='POST' && url.pathname==='/api/tasks'){
      const b=normalizeTask(await body(req)); if(!b.task) return send(res,400,{error:'Task is required.'});
      const tasks=await readTasks();
      const dup=tasks.find(t=>ACTIVE.has(t.status) && t.task.toLowerCase()===b.task.toLowerCase());
      if(dup) return send(res,409,{error:'A matching active task already exists.',task:dup});
      tasks.push(b); await saveTasks(tasks); return send(res,201,{ok:true});
    }
    const m=url.pathname.match(/^\/api\/tasks\/(\d+)$/);
    if(m && req.method==='PATCH'){
      const row=Number(m[1]); const patch=await body(req); const tasks=await readTasks();
      if(!tasks[row]) return send(res,404,{error:'Task not found.'});
      const next=normalizeTask({...tasks[row],...patch});
      if(next.status==='Completed' && !next.completed) next.completed=today();
      if(next.status!=='Completed' && patch.status) next.completed='';
      tasks[row]=next; await saveTasks(tasks); return send(res,200,{ok:true});
    }
    if(req.method==='GET' && url.pathname==='/api/export') return send(res,200,await readRaw(),'text/csv; charset=utf-8');
    return send(res,404,{error:'Not found'});
  } catch(e){ return send(res,500,{error:e.message}); }
}

async function staticFile(req,res,url){
  let rel=url.pathname==='/'?'index.html':url.pathname.replace(/^\//,'');
  const file=path.normalize(path.join(PUBLIC,rel)); if(!file.startsWith(PUBLIC)) return send(res,403,'Forbidden','text/plain');
  try{
    const buf=await fs.readFile(file); const ext=path.extname(file);
    const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.svg':'image/svg+xml'};
    send(res,200,buf,types[ext]||'application/octet-stream');
  } catch { send(res,404,'Not found','text/plain'); }
}

http.createServer(async (req,res)=>{ const url=new URL(req.url,`http://${req.headers.host}`); if(url.pathname.startsWith('/api/')) return api(req,res,url); return staticFile(req,res,url); }).listen(PORT,()=>console.log(`Worklist website running on port ${PORT}`));
