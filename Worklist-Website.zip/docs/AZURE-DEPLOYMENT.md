# Publish Worklist as a website on Azure

## Recommended architecture

Browser -> Azure App Service (Worklist Node website/API) -> Microsoft Graph -> SharePoint `GPT To Do Database.csv`

Protect the website with Microsoft Entra using Azure App Service Authentication (Easy Auth). The application code does not store user passwords.

## 1. Create Microsoft Entra application for SharePoint access

Ask your Microsoft 365 / Azure administrator to create or approve an Entra app registration for Worklist.

Recommended Graph permission approach: use the minimum permission your organization approves, ideally site-scoped access such as `Sites.Selected`, then grant that application access only to the SharePoint/OneDrive site holding the task database. If your tenant does not allow this pattern, your administrator must choose the appropriate delegated/application permission.

Create a client secret or certificate. A certificate/managed identity is preferable for a hardened production deployment; the current website supports a client secret for straightforward setup.

Record:
- Tenant ID
- Client ID
- Client secret

## 2. Identify the SharePoint database file

The production database should remain named `GPT To Do Database.csv`.

Record either:
- Microsoft Graph drive ID + item ID, or
- exact Graph `/content` URL for the file.

The website never creates a substitute database in SharePoint; it reads and replaces the exact configured file.

## 3. Create Azure App Service

Create a Linux Web App using Node 20. The startup command can be left as the package default (`npm start`) or set to `node server.js`.

Add these App Service environment variables:

```
STORAGE_MODE=sharepoint
AZURE_TENANT_ID=<tenant id>
AZURE_CLIENT_ID=<client id>
AZURE_CLIENT_SECRET=<secret>
SHAREPOINT_DRIVE_ID=<drive id>
SHAREPOINT_ITEM_ID=<item id>
```

Alternatively set `SHAREPOINT_FILE_CONTENT_URL` instead of the drive/item pair.

## 4. Protect the website

In Azure App Service -> Authentication:
1. Add Microsoft as an identity provider.
2. Require authentication.
3. Restrict access to your organization/tenant as required by OneMain policy.

This makes the product a normal internal website with Microsoft sign-in.

## 5. Deploy from GitHub

Add repository variable:
- `AZURE_WEBAPP_NAME`

Add repository secret:
- `AZURE_WEBAPP_PUBLISH_PROFILE`

Push to `main`. The included GitHub Actions workflow deploys the site.

## 6. Validate

After deployment:
1. Visit `/api/health` and confirm `{"ok":true,"storage":"sharepoint"}`.
2. Open the website and create one test task.
3. Confirm the row appears in SharePoint `GPT To Do Database.csv`.
4. Mark it completed and confirm Status and Completed Date update without deleting the record.
5. Verify search and Completed views still show the historical record.

## Security notes

- Do not commit `.env` files, client secrets, Graph tokens, or publish profiles.
- Prefer Azure Key Vault / managed identity for production secrets where available.
- Use least-privilege Microsoft Graph access.
- Keep the SharePoint file as the permanent source of truth.
